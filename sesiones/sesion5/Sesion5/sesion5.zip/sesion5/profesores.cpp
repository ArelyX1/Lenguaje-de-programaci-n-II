#include <iostream>
#include <vector>
#include <string>
#include <memory>
#include <unordered_map>

using namespace std;

class IProfesor {
public:
    virtual string getNombre() const = 0;
    virtual float getSueldo() const = 0;
    virtual ~IProfesor() {}
};

class ProfesorPrincipal : public IProfesor {
private:
    string nombre;
    float sueldo;
public:
    ProfesorPrincipal(const string& nombre, float sueldo) : nombre(nombre), sueldo(sueldo) {}
    string getNombre() const override {
        return nombre;
    }
    float getSueldo() const override {
        return sueldo;
    }
};

class ProfesorIterino : public IProfesor {
private:
    string nombre;
    float sueldo;
    const ProfesorPrincipal* profesor_principal;
public:
    ProfesorIterino(const string& nombre, const ProfesorPrincipal* profesor_principal)
        : nombre(nombre), profesor_principal(profesor_principal) {
        this->sueldo = profesor_principal->getSueldo() * 0.8;
    }
    string getNombre() const override {
        return nombre;
    }
    float getSueldo() const override {
        return sueldo;
    }
};

class Escuela {
private:
    unordered_map<string, unique_ptr<IProfesor>> profesores;
public:
    void agregarProfesor(unique_ptr<IProfesor> profesor) {
        profesores[profesor->getNombre()] = std::move(profesor);
    }
    const IProfesor* buscarProfesor(const string& nombre) const {
        auto iter = profesores.find(nombre);
        if (iter != profesores.end()) {
            return iter->second.get();
        }
        return nullptr;
    }
};

int main() {
    Escuela escuela;
    int opcion;
    string nombre;
    float sueldo;
    unique_ptr<ProfesorPrincipal> profesor_principal;
    unique_ptr<ProfesorIterino> profesor_iterino;

    while (true) {
        cout << "1. Agregar profesor principal" << endl;
        cout << "2. Agregar profesor iterino" << endl;
        cout << "3. Buscar profesor" << endl;
        cout << "4. Ver información de profesor" << endl;
        cout << "5. Salir" << endl;
        cin >> opcion;

        switch (opcion) {
            case 1:
                cout << "Ingrese el nombre del profesor principal: ";
                cin >> nombre;
                cout << "Ingrese el sueldo del profesor principal: ";
                cin >> sueldo;
                profesor_principal = make_unique<ProfesorPrincipal>(nombre, sueldo);
                escuela.agregarProfesor(std::move(profesor_principal));
                break;
            case 2:
                cout << "Ingrese el nombre del profesor iterino: ";
                cin >> nombre;
                cout << "Ingrese el nombre del profesor principal a reemplazar: ";
                string nombrePrincipal;
                cin >> nombrePrincipal;
                if (const IProfesor* profesor = escuela.buscarProfesor(nombrePrincipal)) {
                    profesor_iterino = make_unique<ProfesorIterino>(nombre, dynamic_cast<const ProfesorPrincipal*>(profesor));
                    escuela.agregarProfesor(std::move(profesor_iterino));
                } else {
                    cout << "Profesor principal no encontrado." << endl;
                }
                break;
            case 3:
                cout << "Ingrese el nombre del profesor a buscar: ";
                cin >> nombre;
                if (const IProfesor* profesor = escuela.buscarProfesor(nombre)) {
                    cout << "Profesor encontrado" << endl;
                } else {
                    cout << "Profesor no encontrado" << endl;
                }
                break;
            case 4:
                cout << "Ingrese el nombre del profesor para ver su información: ";
                cin >> nombre;
                if (const IProfesor* profesor = escuela.buscarProfesor(nombre)) {
                    cout << "Nombre: " << profesor->getNombre() << ", Sueldo: " << profesor->getSueldo() << endl;
                } else {
                    cout << "Profesor no encontrado" << endl;
                }
                break;
            case 5:
                return 0;
            default:
                cout << "Opción no válida. Por favor, ingrese una opción válida." << endl;
        }
    }
}